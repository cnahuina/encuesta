

    <div class="form-group">
        <label for="inputEmail4">Nombre</label>
        <input type="text" class="form-control" id="inputEmail4" placeholder="Nombre">
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Email</label>
            <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
        </div>
        <div class="form-group col-md-6">
            <label for="inputTelefono">Nro Telefónico</label>
            <input type="text" class="form-control" id="inputTelefono" placeholder="Nro Telefónico">
        </div>
    </div>
    <div class="form-group">
        <label for="inputAddress">Edad</label>
        <input type="text" class="form-control" id="inputEdad" placeholder="Ingrese su edad">
    </div>
    <div class="form-row">

        <div class="form-group col-md-6">
            <label for="inputAddress2">Nro Boleta</label>
            <input type="text" class="form-control" id="inputBoleta" placeholder="Ingrese Nro de boleta">
        </div>

        <div class="form-group col-md-6">
        <label for="inputState">Tienda</label>
        <select id="inputState" style="padding:2%" class="form-control">
            <option selected>Mall del Sur(M)</option>
            <option selected>Mall del Sur(T)</option>
            <option selected>Plaza Norte(T)</option>
            <option selected>Plaza Norte(M)</option>
            <option>...</option>
        </select>
        </div>

    </div>
    <div class="form-group">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="gridCheck">
            <label class="form-check-label" for="gridCheck">
                Acepto términos y condiciones
            </label>
        </div>
    </div>
